bootGame = {
    create:function(){
        game.physics.startSystem(Phaser.Physics.ARCADE);
        
        game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
        game.scale.forceLascape = true;
        game.scale.pageAlignHorizontally = true;
        game.scale.pageAlignVertically = true;
        game.world.setBounds(0,0,800,1400);

        
        game.state.start("preloadGame");
        
        
    },
        update: function () {
        game.scale.pageAlignVertically = true;
        game.scale.pageAlignHorizontally = true;
        game.scale.setShowAll();
        game.scale.refresh();
    }

}
preloadGame = {
    preload:function(){
    game.load.image('bg','img/darkblue.png');
    game.load.image('ledge','img/ledge1.png');
    game.load.image('ledge2','img/ledge2.png');
    game.load.spritesheet('ball','img/ball.png',164,250);
    game.load.image('jump','img/star.png');
    game.load.image('retry','img/restart.png');
    game.load.image("title","img/front.png");
    game.load.image('about2','img/about.png');
    game.load.image('instruction','img/ins.png');
    game.load.audio('kansyon','audio/kansyonmenu.mp3');



    game.load.spritesheet("menu2","img/menu2.png",327,9);
    game.load.spritesheet("start","img/play.png",342,283);
    game.load.spritesheet("about","img/aboutb.png",320,112);
    game.load.spritesheet('pauseButton','img/pause.png',115,148);
    game.load.spritesheet("menu","img/MENU.png",228,95);
    game.load.spritesheet("intruc","img/instruc.png",364,168);



    },
    create:function(){
        game.state.start("menuGame");
    }
}
menuGame = {
    create:function(){

        titlepage = game.add.sprite(0,0, "title");
        startButton = game.add.button(223,700,'start', this.actionOnClick, this);
        aboutButton = game.add.button(235,950,'about',this.aboutOnClick, this);
        instructionButton = game.add.button(240,1060,'intruc',this.instructionOnClick, this);
        menu = game.add.sprite(0,0,"menu");
        
        menu.scale.x = 1.5;
        menu.scale.y = 1.5;

    },

    loopAudio:function(time){
    setInterval(function(){
    kansyon.play();
    },time)
},


    actionOnClick: function(){
        titlepage.visible =! startButton.visible;
        startButton.destroy();
        game.state.start("playGame");

    },


    

 aboutOnClick: function(){
            aboutpage=game.add.image(0,0,"about2");
            restartButton=game.add.button(700,70,"menu2",restartB,this);
            function restartB() {
            aboutpage.visible =! restartButton.visible;
            restartButton.destroy();

            window.location.href=window.location.href;
            }
        },


instructionOnClick: function(){
            instructionpage=game.add.image(0,0,"instruction");
            restartButton=game.add.button(700,70,"menu2",restartB,this);
            function restartB() {
            instructionpage.visible =! restartButton.visible;
            restartButton.destroy();

            window.location.href=window.location.href;
            }
        },


      
}
playGame = {
	create:function(){
		game.physics.startSystem(Phaser.Physics.ARCADE);
        game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
        game.scale.forcePortrait = false;
        game.scale.forceLandscape = true;
        game.scale.pageAlignHorizontally = true;
        game.scale.pageAlignVertically = true;;
        game.scale.setScreenSize = true;
    game.add.sprite(0,0,'bg');
    player = game.add.sprite(320,580,'ball');
   
    platform = game.add.sprite(80,1080,'ledge');
    platform2 = game.add.sprite(600,300,'ledge2');
   
   button = game.add.button(9,580,'jump',lundag);
    button.scale.y = 8;
    button.scale.x = 8;
  
    keyboard = game.input.keyboard.createCursorKeys();

    game.physics.arcade.enable(platform);
    platform.body.movable=true;
    platform.scale.x = 2;
    
    game.physics.arcade.enable(platform2);
    platform2.body.movable=true;
    platform2.scale.x = 2;

    game.physics.arcade.enable(player);
    game.physics.arcade.enable(platform);
    game.physics.arcade.enable(platform2);
    player.body.collideWorldBounds = true;
    platform.body.collideWorldBounds = true;
    platform2.body.collideWorldBounds = true;
    player.body.gravity.y = 1000;
    platform.body.gravity.y = 100;
    platform2.body.gravity.y = -80;
    platform.body.bounce.y = 1.1;
    platform2.body.bounce.y = 1.1;
    

    keyboard=game.input.keyboard.createCursorKeys();
    
    score=game.add.text(300,200,"0 ",{font:'150px Chalkduster', fill:'white'});
    
    hi=game.add.text(60,120,"HIGH SCORE: " +this.getScore(),{font:'35px Arial Black', fill:'white'});
    
    sipa = game.add.text(120,300,'Game Over!',{font: '100px Arial',fill:'white'});
    sipa.visible = false;
    
    stateText = game.add.text(game.world.centerX,game.world.centerY,' ', { font: '90px Arial Black', fill: 'white' });
    stateText.anchor.setTo(0.5, 0.5);
    stateText.visible = false;
    
    

    highscore=game.add.text(190,800,"Current Best: " +this.getScore(),{font:'50px Arial Black', fill:'gold'});
    highscore.visible=false;

    
    scoremo=game.add.text(140,1120,"Your Score: ",{font:'70px Arial Black ', fill:'white'});
    scoremo.visible=false;

    button = game.add.button(9,580,'jump',this.lundag);
    button.scale.y = 8;
    button.scale.x = 8;

this.pauseButton = this.game.add.sprite(640, 90, 'pauseButton');
this.pauseButton.inputEnabled = true;
this.pauseButton.events.onInputUp.add(function () {this.game.paused = true;},this);
this.game.input.onDown.add(function () {if(this.game.paused)this.game.paused = false;},this);



        kansyon =game.add.audio("kansyon",1,true);
        kansyon.Loop =true;
        kansyon.play();




},

update: function() {

    score.text = " " +x;
    scoremo.text = "Your Score : " +x;
    if(this.getScore()<=x){
            this.saveScore(x);
            hi.text="HIGH SCORE: "+x;
        }
    
    if (game.physics.arcade.collide(platform,player)){

        game._paused=true
        sipa.visible =true;

        kansyon.stop();
        
        this.restart.visible = true;
        highscore.visible=true;
        // scoremo.visible=true


                stateText.text="Tap to restart";
                stateText.visible = true;

                
                game.input.onTap.addOnce(this.restart,this);

    }


     
if (game.physics.arcade.collide(platform2,player)){


        game._paused=true
        sipa.visible =true;
        
        this.restart.visible = true;
        
        highscore.visible=true;
        // scoremo.visible=true
    

                stateText.text="Tap to restart";
                stateText.visible = true;

              
                game.input.onTap.addOnce(this.restart,this);
        
    
    
    }

    },
    lundag: function()
        {
        x = x+1;
        score.text="Score: "+x;
        player.body.velocity.y = -500;
  


        },


    saveScore:function(score){
        localStorage.setItem("gameData", score);
    },

    getScore:function (){
        return (localStorage.getItem("gameData")== null || localStorage.getItem("gameData")=="")?0:
        localStorage.getItem("gameData");
    },


    restart:function  () {

    window.location.href=window.location.href;
    stateText.visible = false;
},


};
// game.state.add('play', BasicGame, true);





	
winGame = {
    
}
loseGame = {
    
}

